package com.veryon.client.touch;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

/**
 * Renders on-screen touch controls: a movement joystick (bottom-left) and
 * action buttons for attack/use/jump/sneak (bottom-right). Positions are
 * kept away from screen center so they never overlap the crosshair.
 *
 * NOTE: this class currently only draws the overlay. Wiring these buttons
 * to actual input (synthetic key presses / touch event handling) depends
 * on which mobile runtime Veryon targets:
 *  - If running under PojavLauncher, touch-to-input is already handled by
 *    the launcher; you'd mainly need this overlay to *replace* or restyle
 *    PojavLauncher's default buttons with Veryon's own, which means hooking
 *    into whatever touch event system it exposes rather than starting from
 *    scratch.
 *  - If building a fully custom touch layer, you'll need to register a
 *    touch/mouse-down region listener per button here and translate taps
 *    into the same KeyBinding.setPressed() calls vanilla input uses.
 * Confirm the runtime before wiring input, since the two paths are very
 * different.
 */
public class TouchControlOverlay {

	private static final int JOYSTICK_RADIUS = 40;
	private static final int JOYSTICK_MARGIN = 30;
	private static final int BUTTON_SIZE = 36;
	private static final int BUTTON_GAP = 8;
	private static final int BUTTON_MARGIN = 30;

	private static final int COLOR_BASE = 0x60FFFFFF;
	private static final int COLOR_STICK = 0x904C8DFF;
	private static final int COLOR_BUTTON = 0x70000000;

	public void render(DrawContext context, MinecraftClient client) {
		int screenWidth = client.getWindow().getScaledWidth();
		int screenHeight = client.getWindow().getScaledHeight();

		renderJoystick(context, screenWidth, screenHeight);
		renderActionButtons(context, client, screenWidth, screenHeight);
	}

	private void renderJoystick(DrawContext context, int screenWidth, int screenHeight) {
		int centerX = JOYSTICK_MARGIN + JOYSTICK_RADIUS;
		int centerY = screenHeight - JOYSTICK_MARGIN - JOYSTICK_RADIUS;

		// Base ring (drawn as a filled square placeholder — swap for a
		// circular texture in your resource pack for the real UI).
		context.fill(centerX - JOYSTICK_RADIUS, centerY - JOYSTICK_RADIUS,
				centerX + JOYSTICK_RADIUS, centerY + JOYSTICK_RADIUS, COLOR_BASE);

		// Stick, currently drawn centered/idle. Once input is wired up,
		// offset this by the current drag vector, clamped to JOYSTICK_RADIUS.
		int stickRadius = JOYSTICK_RADIUS / 2;
		context.fill(centerX - stickRadius, centerY - stickRadius,
				centerX + stickRadius, centerY + stickRadius, COLOR_STICK);
	}

	private void renderActionButtons(DrawContext context, MinecraftClient client, int screenWidth, int screenHeight) {
		int baseX = screenWidth - BUTTON_MARGIN - BUTTON_SIZE;
		int baseY = screenHeight - BUTTON_MARGIN - BUTTON_SIZE;

		// Attack (bottom-right most)
		drawButton(context, client, "ATK", baseX, baseY);
		// Use item, stacked above attack
		drawButton(context, client, "USE", baseX, baseY - BUTTON_SIZE - BUTTON_GAP);
		// Jump, to the left of attack
		drawButton(context, client, "JMP", baseX - BUTTON_SIZE - BUTTON_GAP, baseY);
		// Sneak, diagonal
		drawButton(context, client, "SNK", baseX - BUTTON_SIZE - BUTTON_GAP, baseY - BUTTON_SIZE - BUTTON_GAP);
	}

	private void drawButton(DrawContext context, MinecraftClient client, String label, int x, int y) {
		context.fill(x, y, x + BUTTON_SIZE, y + BUTTON_SIZE, COLOR_BUTTON);
		context.drawCenteredTextWithShadow(client.textRenderer, Text.literal(label),
				x + BUTTON_SIZE / 2, y + BUTTON_SIZE / 2 - 4, 0xFFFFFF);
	}
}
