package com.veryon.client.gui;

import com.veryon.client.VeryonClient;
import com.veryon.client.module.Module;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.List;

/**
 * Full-screen, single-column settings menu — one category at a time,
 * large buttons instead of a dense desktop ClickGUI. This is the mobile
 * equivalent of a ClickGUI: still works fine on desktop, just uses more
 * screen space per option than a power-user would want there.
 */
public class VeryonSettingsScreen extends Screen {

	private static final int BUTTON_HEIGHT = 24;
	private static final int BUTTON_GAP = 6;
	private static final int BUTTON_WIDTH_RATIO = 70; // percent of screen width

	private Module.Category currentCategory = Module.Category.HUD;

	public VeryonSettingsScreen() {
		super(Text.literal("Veryon Settings"));
	}

	@Override
	protected void init() {
		super.init();
		rebuildButtons();
	}

	private void rebuildButtons() {
		clearChildren();

		int buttonWidth = width * BUTTON_WIDTH_RATIO / 100;
		int startX = (width - buttonWidth) / 2;

		// Category tabs across the top.
		Module.Category[] categories = Module.Category.values();
		int tabWidth = width / categories.length;
		for (int i = 0; i < categories.length; i++) {
			Module.Category category = categories[i];
			addDrawableChild(ButtonWidget.builder(
					Text.literal(category.name()),
					btn -> {
						currentCategory = category;
						rebuildButtons();
					}
			).dimensions(i * tabWidth, 20, tabWidth, BUTTON_HEIGHT).build());
		}

		// One toggle button per module in the selected category.
		List<Module> modules = VeryonClient.getModuleManager().getByCategory(currentCategory);
		int y = 60;
		for (Module module : modules) {
			addDrawableChild(ButtonWidget.builder(
					toggleLabel(module),
					btn -> {
						module.toggle();
						btn.setMessage(toggleLabel(module));
					}
			).dimensions(startX, y, buttonWidth, BUTTON_HEIGHT).build());
			y += BUTTON_HEIGHT + BUTTON_GAP;
		}
	}

	private Text toggleLabel(Module module) {
		String state = module.isEnabled() ? "ON" : "OFF";
		return Text.literal(module.getName() + ": " + state);
	}

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		renderBackground(context, mouseX, mouseY, delta);
		super.render(context, mouseX, mouseY, delta);
		context.drawCenteredTextWithShadow(textRenderer, title, width / 2, 6, 0xFFFFFF);
	}

	@Override
	public boolean shouldPause() {
		return false;
	}
}
