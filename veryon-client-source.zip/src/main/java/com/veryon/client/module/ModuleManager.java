package com.veryon.client.module;

import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

/**
 * Central registry for every Module. Handles ticking and rendering,
 * and switches between desktop/compact layouts based on
 * VeryonClient.isCompactLayout().
 */
public class ModuleManager {

	private final List<Module> modules = new ArrayList<>();
	private boolean compactLayout = false;

	public void register(Module module) {
		modules.add(module);
	}

	public List<Module> getModules() {
		return Collections.unmodifiableList(modules);
	}

	public Optional<Module> getByName(String name) {
		return modules.stream()
				.filter(m -> m.getName().equalsIgnoreCase(name))
				.findFirst();
	}

	public List<Module> getByCategory(Module.Category category) {
		return modules.stream()
				.filter(m -> m.getCategory() == category)
				.toList();
	}

	public void setCompactLayout(boolean compact) {
		this.compactLayout = compact;
	}

	public boolean isCompactLayout() {
		return compactLayout;
	}

	public void tick() {
		for (Module module : modules) {
			if (module.isEnabled()) {
				module.onTick();
			}
		}
	}

	public void render(DrawContext context, float tickDelta) {
		for (Module module : modules) {
			if (!module.isEnabled()) {
				continue;
			}
			if (compactLayout) {
				module.renderCompact(context, tickDelta);
			} else {
				module.render(context, tickDelta);
			}
		}
	}
}
