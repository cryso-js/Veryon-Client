package com.veryon.client.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * Base class for every Veryon feature: HUD elements, keystrokes, cosmetics
 * toggles, combat-assist indicators, etc.
 *
 * Each module knows how to render itself in two layouts:
 *  - render()       -> desktop layout
 *  - renderCompact() -> mobile layout (small screens, touch devices)
 *
 * Subclasses only need to override the pieces they actually use.
 */
public abstract class Module {

	protected final MinecraftClient client = MinecraftClient.getInstance();

	private final String name;
	private final Category category;
	private boolean enabled;

	/** Screen-space position, used by both layouts unless a module overrides it. */
	private int x;
	private int y;

	public Module(String name, Category category, boolean enabledByDefault) {
		this.name = name;
		this.category = category;
		this.enabled = enabledByDefault;
	}

	public enum Category {
		HUD,
		COMBAT,
		COSMETIC,
		TOUCH
	}

	// --- lifecycle -----------------------------------------------------

	/** Called every client tick while enabled. Override for logic (timers, state tracking). */
	public void onTick() {
	}

	/** Desktop render pass. Override to draw this module's HUD element. */
	public void render(DrawContext context, float tickDelta) {
	}

	/**
	 * Compact/mobile render pass. Defaults to calling render() so modules
	 * work out of the box on mobile; override this for a real compact layout
	 * (smaller text, collapsed info, finger-sized hit targets for anything
	 * interactive).
	 */
	public void renderCompact(DrawContext context, float tickDelta) {
		render(context, tickDelta);
	}

	// --- state -----------------------------------------------------------

	public String getName() {
		return name;
	}

	public Category getCategory() {
		return category;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
		if (enabled) {
			onEnable();
		} else {
			onDisable();
		}
	}

	public void toggle() {
		setEnabled(!enabled);
	}

	protected void onEnable() {
	}

	protected void onDisable() {
	}

	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

	public void setPosition(int x, int y) {
		this.x = x;
		this.y = y;
	}
}
