package com.veryon.client.module.modules;

import com.veryon.client.module.Module;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.text.Text;

/**
 * Classic "keystrokes" overlay: shows WASD + mouse buttons and highlights
 * them while pressed. Desktop layout draws a full WASD block; compact
 * layout collapses this to a small 3-button cluster (forward / attack /
 * use) since screen space on mobile is tight.
 */
public class KeystrokesModule extends Module {

	private static final int BOX_SIZE = 18;
	private static final int GAP = 2;
	private static final int COLOR_IDLE = 0x80000000;
	private static final int COLOR_ACTIVE = 0xA04C8DFF;

	public KeystrokesModule() {
		super("Keystrokes", Category.HUD, true);
		setPosition(10, 10);
	}

	@Override
	public void render(DrawContext context, float tickDelta) {
		if (client.options == null) {
			return;
		}

		int baseX = getX();
		int baseY = getY();

		// Top row: W
		drawKey(context, client.options.forwardKey, "W", baseX + BOX_SIZE + GAP, baseY);

		// Middle row: A S D
		drawKey(context, client.options.leftKey, "A", baseX, baseY + BOX_SIZE + GAP);
		drawKey(context, client.options.backKey, "S", baseX + BOX_SIZE + GAP, baseY + BOX_SIZE + GAP);
		drawKey(context, client.options.rightKey, "D", baseX + 2 * (BOX_SIZE + GAP), baseY + BOX_SIZE + GAP);

		// Bottom row: space bar (wide)
		int spaceWidth = 3 * BOX_SIZE + 2 * GAP;
		boolean jumpPressed = client.options.jumpKey.isPressed();
		context.fill(baseX, baseY + 2 * (BOX_SIZE + GAP), baseX + spaceWidth,
				baseY + 2 * (BOX_SIZE + GAP) + BOX_SIZE, jumpPressed ? COLOR_ACTIVE : COLOR_IDLE);
		context.drawCenteredTextWithShadow(client.textRenderer, Text.literal("JUMP"),
				baseX + spaceWidth / 2, baseY + 2 * (BOX_SIZE + GAP) + BOX_SIZE / 2 - 4, 0xFFFFFF);
	}

	@Override
	public void renderCompact(DrawContext context, float tickDelta) {
		if (client.options == null) {
			return;
		}

		// Compact: single row, forward / attack(use item slot) / use.
		int baseX = getX();
		int baseY = getY();
		int size = 14;
		int gap = 2;

		drawKey(context, client.options.forwardKey, "FWD", baseX, baseY, size);
		drawKey(context, client.options.attackKey, "ATK", baseX + size + gap, baseY, size);
		drawKey(context, client.options.useKey, "USE", baseX + 2 * (size + gap), baseY, size);
	}

	private void drawKey(DrawContext context, KeyBinding key, String label, int x, int y) {
		drawKey(context, key, label, x, y, BOX_SIZE);
	}

	private void drawKey(DrawContext context, KeyBinding key, String label, int x, int y, int size) {
		boolean pressed = key.isPressed();
		context.fill(x, y, x + size, y + size, pressed ? COLOR_ACTIVE : COLOR_IDLE);
		context.drawCenteredTextWithShadow(client.textRenderer, Text.literal(label),
				x + size / 2, y + size / 2 - 4, 0xFFFFFF);
	}
}
