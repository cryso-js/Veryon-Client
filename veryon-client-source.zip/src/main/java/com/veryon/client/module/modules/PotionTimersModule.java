package com.veryon.client.module.modules;

import com.veryon.client.module.Module;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;

import java.util.Collection;

/**
 * Lists active potion effects with remaining duration. Compact layout
 * shows fewer effects and shorter labels to fit small screens.
 */
public class PotionTimersModule extends Module {

	public PotionTimersModule() {
		super("Potion Timers", Category.HUD, true);
		setPosition(10, 140);
	}

	@Override
	public void render(DrawContext context, float tickDelta) {
		renderEffects(context, Integer.MAX_VALUE, false);
	}

	@Override
	public void renderCompact(DrawContext context, float tickDelta) {
		renderEffects(context, 3, true);
	}

	private void renderEffects(DrawContext context, int maxEffects, boolean shortLabels) {
		PlayerEntity player = client.player;
		if (player == null) {
			return;
		}

		Collection<StatusEffectInstance> effects = player.getStatusEffects();
		if (effects.isEmpty()) {
			return;
		}

		int lineHeight = client.textRenderer.fontHeight + 2;
		int i = 0;

		for (StatusEffectInstance effect : effects) {
			if (i >= maxEffects) {
				break;
			}

			String name = effect.getEffectType().value().getName().getString();
			if (shortLabels && name.length() > 10) {
				name = name.substring(0, 10) + ".";
			}

			int seconds = effect.getDuration() / 20;
			String line = String.format("%s %d:%02d", name, seconds / 60, seconds % 60);

			context.drawTextWithShadow(client.textRenderer, Text.literal(line),
					getX(), getY() + i * lineHeight, 0xFFFFFF);
			i++;
		}
	}
}
