package com.veryon.client.module.modules;

import com.veryon.client.module.Module;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.text.Text;

/**
 * Displays the player's coordinates. Desktop shows X / Y / Z on separate
 * lines; compact collapses to one line to save vertical space.
 */
public class CoordsModule extends Module {

	public CoordsModule() {
		super("Coords", Category.HUD, true);
		setPosition(10, 80);
	}

	@Override
	public void render(DrawContext context, float tickDelta) {
		Entity player = client.getCameraEntity();
		if (player == null) {
			return;
		}

		int x = getX();
		int y = getY();
		int lineHeight = client.textRenderer.fontHeight + 2;

		context.drawTextWithShadow(client.textRenderer,
				Text.literal(String.format("X: %.1f", player.getX())), x, y, 0xFFFFFF);
		context.drawTextWithShadow(client.textRenderer,
				Text.literal(String.format("Y: %.1f", player.getY())), x, y + lineHeight, 0xFFFFFF);
		context.drawTextWithShadow(client.textRenderer,
				Text.literal(String.format("Z: %.1f", player.getZ())), x, y + 2 * lineHeight, 0xFFFFFF);
	}

	@Override
	public void renderCompact(DrawContext context, float tickDelta) {
		Entity player = client.getCameraEntity();
		if (player == null) {
			return;
		}

		String line = String.format("%.0f, %.0f, %.0f", player.getX(), player.getY(), player.getZ());
		context.drawTextWithShadow(client.textRenderer, Text.literal(line), getX(), getY(), 0xFFFFFF);
	}
}
