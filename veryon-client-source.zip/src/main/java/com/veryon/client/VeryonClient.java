package com.veryon.client;

import com.veryon.client.module.Module;
import com.veryon.client.module.ModuleManager;
import com.veryon.client.module.modules.CoordsModule;
import com.veryon.client.module.modules.KeystrokesModule;
import com.veryon.client.module.modules.PotionTimersModule;
import com.veryon.client.touch.TouchControlOverlay;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;

/**
 * Entrypoint for Veryon Client.
 *
 * Registers all built-in modules, hooks the HUD render + tick events, and
 * decides at runtime whether to use the desktop or compact/touch layout.
 *
 * Layout detection is currently a manual toggle (see isCompactLayout /
 * FORCE_COMPACT below) — wire this up to an actual PojavLauncher / touch
 * detection signal once you confirm which mobile runtime Veryon targets.
 */
public class VeryonClient implements ClientModInitializer {

	public static final String MOD_ID = "veryon-client";

	private static ModuleManager moduleManager;
	private static TouchControlOverlay touchOverlay;

	/**
	 * Manual override switch for now. Set true to force the mobile/compact
	 * layout regardless of environment — flip this to real detection logic
	 * (e.g. checking a system property PojavLauncher sets, or a config
	 * option) once the mobile runtime is finalized.
	 */
	private static final boolean FORCE_COMPACT = false;

	@Override
	public void onInitializeClient() {
		moduleManager = new ModuleManager();
		touchOverlay = new TouchControlOverlay();

		moduleManager.setCompactLayout(FORCE_COMPACT);

		registerModules();

		// Tick every module once per client tick.
		ClientTickEvents.END_CLIENT_TICK.register(client -> moduleManager.tick());

		// Draw HUD modules (and the touch overlay, if compact layout is active)
		// every frame, after vanilla HUD has drawn.
		HudRenderCallback.EVENT.register((context, tickDelta) -> {
			moduleManager.render(context, tickDelta.getTickDelta(true));

			if (moduleManager.isCompactLayout()) {
				touchOverlay.render(context, MinecraftClient.getInstance());
			}
		});
	}

	private void registerModules() {
		moduleManager.register(new KeystrokesModule());
		moduleManager.register(new CoordsModule());
		moduleManager.register(new PotionTimersModule());
	}

	public static ModuleManager getModuleManager() {
		return moduleManager;
	}

	public static TouchControlOverlay getTouchOverlay() {
		return touchOverlay;
	}
}
