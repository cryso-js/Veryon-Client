# Building & releasing the Veryon APK (PojavLauncher fork)

This covers the launcher side — the actual `.apk` users install. It's a
separate repo from `veryon-client` (the Fabric mod), forked from
PojavLauncher.

## 1. Fork the repo

- Go to https://github.com/PojavLauncherTeam/PojavLauncher on GitHub
- Click **Fork** into your own account/org (e.g. `yourname/veryon-launcher`)
- Check `LICENSE` — it's GPL-3.0. That means **Veryon's launcher fork must
  also be open source under GPL-3.0**, and you must keep PojavLauncher's
  copyright/license notices intact and credit the original project. This
  is a hard requirement of the license, not optional branding advice.

## 2. Rebrand

Things to change in your fork:
- App name / `strings.xml` → "Veryon Client"
- App icon → replace `mipmap` drawables under `app/src/main/res/`
- Package ID (`applicationId` in `app/build.gradle`) → e.g.
  `com.veryon.launcher`, so it doesn't collide with the real PojavLauncher
  on the Play Store / when both are installed
- Splash screen / theme colors → match Veryon's branding

Don't touch the actual JVM/GL4ES/input-bridge native code unless you know
exactly what you're changing — that's the part doing the heavy lifting.

## 3. Bundle the Veryon mod automatically

PojavLauncher supports a `mods` folder per Minecraft version inside its
managed `.minecraft` directory on-device. To auto-bundle Veryon's mod:

- Add the built `veryon-client-*.jar` (from the `veryon-client` repo's
  release) as an asset in your launcher fork's `app/src/main/assets/`
- On first launch (or first profile creation), copy that jar into the
  active instance's `mods/` folder before Fabric loader starts — look at
  how PojavLauncher's own profile/instance setup code works and hook in
  at that point
- This means every release of the Veryon mod jar should be pulled into
  the launcher repo as a new asset when you cut a new mod version — keep
  the two repos' version numbers in sync so you don't ship a launcher
  with a stale mod build

## 4. Wire up TouchControlOverlay (or don't)

Since PojavLauncher already renders its own on-screen controls and
converts touch to synthetic input, you have two options:
- **Simplest**: disable rendering of Veryon's `TouchControlOverlay` and
  just let PojavLauncher's existing controls handle input — you lose
  custom branding on the controls but ship faster
- **Full branding**: dig into PojavLauncher's touch input bridge
  (search their source for how it dispatches touch events to Minecraft's
  input handling) and suppress its default overlay in favor of
  `TouchControlOverlay`, then translate your button/joystick taps into
  the same calls PojavLauncher's bridge makes

## 5. Set up GitHub Actions for the APK build

PojavLauncher's own repo already has a working Actions workflow for
building the APK (check `.github/workflows/` in the repo you forked) —
copy and adapt that rather than writing one from scratch, since it
already handles the Android NDK/native build steps correctly. Typically
you'll:
- Keep their `build.yml` largely as-is for CI (builds on every push)
- Add a release job triggered on version tags, similar to the
  `release.yml` in the `veryon-client` repo, but using
  `actions/upload-release-asset` or `softprops/action-gh-release` to
  attach the built `.apk` instead of a `.jar`

## 6. Cutting a release

Once both repos are set up:
1. Tag and release `veryon-client` (the mod) first — get the jar built
2. Pull that jar into the launcher fork's assets
3. Tag and release the launcher fork — GitHub Actions builds the APK and
   attaches it to the release automatically, same pattern as the mod repo

## Before you publish anything

- Confirm you've kept GPL-3.0 compliance (license file, attribution,
  source availability for your fork) — this isn't optional once you
  distribute a build to other people
- Decide the combat-assist question flagged earlier (informational vs.
  input-assisting) before a wide release, since it affects which servers
  will allow Veryon and how you can describe it
