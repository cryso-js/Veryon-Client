# Veryon Client

A PvP/utility Fabric mod for Minecraft Java Edition, built with mobile
(touch) play as a first-class target rather than an afterthought.

## What's included

```
src/main/java/com/veryon/client/
├── VeryonClient.java              # mod entrypoint, wires everything together
├── module/
│   ├── Module.java                # base class every feature extends
│   ├── ModuleManager.java         # registry, tick + render dispatch
│   └── modules/
│       ├── KeystrokesModule.java  # WASD/attack/use overlay (desktop + compact)
│       ├── CoordsModule.java      # X/Y/Z display
│       └── PotionTimersModule.java# active effect timers
├── touch/
│   └── TouchControlOverlay.java   # virtual joystick + action buttons
└── gui/
    └── VeryonSettingsScreen.java  # full-screen tabbed settings menu
```

This gives you a working skeleton: modules register themselves, tick and
render every frame, and swap between desktop and compact/mobile layouts
via `ModuleManager.isCompactLayout()`. Adding a new HUD element means
extending `Module` and registering it in `VeryonClient.registerModules()`
— you don't need to touch the render loop or tick loop again.

## Building it

This sandbox has no network access, so the project hasn't been compiled
here — Gradle needs to download the Fabric Loom plugin, Minecraft, and
mappings on first run.

**On GitHub (recommended):** the included `.github/workflows/build.yml`
and `release.yml` install Gradle directly on the CI runner (via
`gradle/actions/setup-gradle`), so you don't need a Gradle wrapper
committed to the repo at all — just push and Actions handles the rest.

**Building locally:**
1. Install a JDK 21 (Temurin/Adoptium works well) and Gradle 8.8+.
2. Unzip the project, then from the project root run: `gradle build`
3. The built mod jar lands in `build/libs/`.
4. Drop it into a Fabric-loader `.minecraft/mods` folder (Fabric API jar
   must also be present) to test on desktop.

If you'd rather use the `./gradlew` wrapper script locally (so you don't
need Gradle pre-installed), run `gradle wrapper --gradle-version 8.8`
once inside the project — that generates the missing wrapper jar and
commits cleanly to git from then on.

## What's still a stub, on purpose

- **Touch input wiring** — `TouchControlOverlay` currently only *draws*
  the joystick and buttons; it doesn't yet translate taps into movement.
  How you wire that depends entirely on your mobile runtime:
  - **PojavLauncher**: it already converts touch into synthetic
    mouse/keyboard events, so your real task is either (a) leaving
    PojavLauncher's own on-screen controls active and just skip
    rendering `TouchControlOverlay` entirely, or (b) if you want
    Veryon-branded controls, digging into PojavLauncher's input
    bridge to suppress its default overlay and register your own touch
    listeners in its place.
  - **Fully custom runtime**: you'd register touch-down/drag/up
    listeners here and call `KeyBinding.setPressed(true/false)` on the
    relevant vanilla keybinds, plus compute a movement vector from the
    joystick drag distance.
  This was left unwired because it changes significantly based on
  which runtime answer you land on — let me know once that's settled
  and I'll wire it against the real one.
- **Cosmetics (capes/hats)** — not yet started. This needs a
  `PlayerEntityRenderer` mixin plus a small backend (even a static JSON
  file mapping username → cosmetic ID works to start) to fetch what
  each player has equipped.
- **Combat-assist indicators** (reach/hit-timing display) — deliberately
  not included in this pass. Worth deciding up front whether these stay
  informational (just *showing* your reach/ping) or start assisting
  input, since that changes both anti-cheat compatibility and how
  honestly you can market the client — flagged this earlier and it's
  still worth pinning down before building it.
- **Real UI art** — buttons and the joystick currently render as flat
  colored rectangles so the logic is visible; swap in actual textures
  once you have art direction for Veryon's look.

## Next steps

1. Confirm the mobile runtime (PojavLauncher vs. something else) so
   touch input can actually be wired up.
2. Get a JDK 21 + Gradle environment running locally and confirm
   `./gradlew build` produces a jar.
3. Test the compact layout by setting `FORCE_COMPACT = true` in
   `VeryonClient.java` and running on desktop first — cheaper to
   iterate on layout there before testing on an actual device.
